-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 11, 2019 at 10:33 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `posdbg5`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblaccount`
--

DROP TABLE IF EXISTS `tblaccount`;
CREATE TABLE IF NOT EXISTS `tblaccount` (
  `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Special_Type` tinyint(1) DEFAULT NULL,
  `Name` varchar(40) NOT NULL,
  `Position` varchar(30) NOT NULL,
  `Password` varchar(40) NOT NULL,
  `Setting_perm` tinyint(1) NOT NULL,
  `Report_perm` tinyint(1) NOT NULL,
  `Cash_perm` tinyint(1) NOT NULL,
  `Stock_perm` tinyint(1) NOT NULL,
  `Customer_perm` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblaccount`
--

INSERT INTO `tblaccount` (`ID`, `Special_Type`, `Name`, `Position`, `Password`, `Setting_perm`, `Report_perm`, `Cash_perm`, `Stock_perm`, `Customer_perm`) VALUES
(1, 1, 'Admin', 'Administrator', '1234', 1, 1, 1, 1, 1),
(7, 0, 'Dara', 'General', '1234', 1, 0, 1, 0, 0),
(8, 0, 'Ly meng', 'General', '1234', 0, 0, 1, 1, 0),
(9, 0, 'Thea Gay', 'General', '1234', 0, 0, 1, 0, 0),
(10, 0, 'Srong', 'General', '123', 0, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblaccounttype`
--

DROP TABLE IF EXISTS `tblaccounttype`;
CREATE TABLE IF NOT EXISTS `tblaccounttype` (
  `ID` bigint(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `AccountType` varchar(30) NOT NULL,
  `Special_Type` tinyint(1) NOT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblaccounttype`
--

INSERT INTO `tblaccounttype` (`ID`, `AccountType`, `Special_Type`) VALUES
(1, 'General', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

DROP TABLE IF EXISTS `tblcategory`;
CREATE TABLE IF NOT EXISTS `tblcategory` (
  `ID` bigint(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Category` varchar(35) NOT NULL,
  `Special_Type` tinyint(1) NOT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`ID`, `Category`, `Special_Type`) VALUES
(1, 'Default', 1),
(4, 'Drinks', 0),
(6, 'Food', 0),
(7, 'Snack', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomers`
--

DROP TABLE IF EXISTS `tblcustomers`;
CREATE TABLE IF NOT EXISTS `tblcustomers` (
  `CusID` int(10) NOT NULL AUTO_INCREMENT,
  `CusName` varchar(35) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Address` varchar(70) NOT NULL,
  `Country_Region` varchar(30) NOT NULL,
  `MemberType` varchar(20) NOT NULL,
  `Special_Type` tinyint(1) NOT NULL,
  PRIMARY KEY (`CusID`),
  UNIQUE KEY `CusID` (`CusID`),
  KEY `MemberType` (`MemberType`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcustomers`
--

INSERT INTO `tblcustomers` (`CusID`, `CusName`, `Phone`, `Address`, `Country_Region`, `MemberType`, `Special_Type`) VALUES
(1, 'To Go', '', '', '', 'General', 1),
(7, 'Nara', '012012012', 'pp', 'cam', 'General', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblmember`
--

DROP TABLE IF EXISTS `tblmember`;
CREATE TABLE IF NOT EXISTS `tblmember` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `MemberType` varchar(20) NOT NULL,
  `Discount` float NOT NULL,
  `Special_Type` tinyint(1) NOT NULL,
  PRIMARY KEY (`MemberType`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmember`
--

INSERT INTO `tblmember` (`ID`, `MemberType`, `Discount`, `Special_Type`) VALUES
(1, 'General', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblproducts`
--

DROP TABLE IF EXISTS `tblproducts`;
CREATE TABLE IF NOT EXISTS `tblproducts` (
  `ID` int(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ProName` varchar(30) NOT NULL,
  `UnitPrice` double NOT NULL,
  `Category` varchar(30) NOT NULL,
  `Quantity` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproducts`
--

INSERT INTO `tblproducts` (`ID`, `ProName`, `UnitPrice`, `Category`, `Quantity`) VALUES
(1, 'Coca', 0.5, 'Drinks', 1000),
(2, 'Burger', 2.5, 'Default', 94),
(4, 'Angkor beer', 0.55, 'Drinks', 1234),
(5, 'Banana', 2.5, 'Default', 87),
(6, 'apple', 2, 'Food', 500),
(7, 'Orange', 0.1, 'Default', 100);

-- --------------------------------------------------------

--
-- Table structure for table `tblreportuser`
--

DROP TABLE IF EXISTS `tblreportuser`;
CREATE TABLE IF NOT EXISTS `tblreportuser` (
  `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Emp_ID` int(10) UNSIGNED NOT NULL,
  `Datelogin` varchar(15) NOT NULL,
  `Timelogin` varchar(15) NOT NULL,
  `Timelogout` varchar(15) NOT NULL,
  `Datelogout` varchar(15) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`),
  KEY `Emp_ID` (`Emp_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblreportuser`
--

INSERT INTO `tblreportuser` (`ID`, `Emp_ID`, `Datelogin`, `Timelogin`, `Timelogout`, `Datelogout`) VALUES
(21, 1, '2019-03-11', '03:37:15 PM  ', '03:37:22 PM  ', '2019-03-11'),
(22, 1, '2019-03-11', '03:37:27 PM  ', '03:37:57 PM  ', '2019-03-11'),
(23, 1, '2019-03-11', '03:38:05 PM  ', '03:38:47 PM  ', '2019-03-11'),
(24, 8, '2019-03-11', '03:38:56 PM  ', '03:39:00 PM  ', '2019-03-11'),
(25, 1, '2019-03-11', '03:39:05 PM  ', '03:40:20 PM  ', '2019-03-11');

-- --------------------------------------------------------

--
-- Table structure for table `tblsales`
--

DROP TABLE IF EXISTS `tblsales`;
CREATE TABLE IF NOT EXISTS `tblsales` (
  `ID` int(10) UNSIGNED NOT NULL,
  `SaleDate` varchar(15) NOT NULL,
  `Time` varchar(15) NOT NULL,
  `Emp_ID` int(11) UNSIGNED NOT NULL,
  `Cust_ID` int(11) DEFAULT NULL,
  `TotalAmount` double NOT NULL,
  `Cashin` double NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`),
  KEY `Emp_ID` (`Emp_ID`,`Cust_ID`),
  KEY `Cust_ID` (`Cust_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsales`
--

INSERT INTO `tblsales` (`ID`, `SaleDate`, `Time`, `Emp_ID`, `Cust_ID`, `TotalAmount`, `Cashin`) VALUES
(1, '10-29-2019', '12:29:43 PM  ', 1, 1, 15, 15),
(2, '11-28-2019', '03:28:27 PM  ', 1, 1, 10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `tblsalesdetails`
--

DROP TABLE IF EXISTS `tblsalesdetails`;
CREATE TABLE IF NOT EXISTS `tblsalesdetails` (
  `ID` int(10) NOT NULL,
  `Sale_ID` int(10) UNSIGNED NOT NULL,
  `Pro_ID` int(11) UNSIGNED NOT NULL,
  `Quantity` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Sale_ID` (`Sale_ID`,`Pro_ID`),
  KEY `Pro_ID` (`Pro_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsalesdetails`
--

INSERT INTO `tblsalesdetails` (`ID`, `Sale_ID`, `Pro_ID`, `Quantity`) VALUES
(1, 1, 5, 5),
(2, 1, 1, 5),
(3, 2, 2, 1),
(4, 1, 5, 3);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblcustomers`
--
ALTER TABLE `tblcustomers`
  ADD CONSTRAINT `tblcustomers_ibfk_1` FOREIGN KEY (`MemberType`) REFERENCES `tblmember` (`MemberType`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblreportuser`
--
ALTER TABLE `tblreportuser`
  ADD CONSTRAINT `tblreportuser_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `tblaccount` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblsales`
--
ALTER TABLE `tblsales`
  ADD CONSTRAINT `tblsales_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `tblaccount` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblsales_ibfk_2` FOREIGN KEY (`Cust_ID`) REFERENCES `tblcustomers` (`CusID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblsalesdetails`
--
ALTER TABLE `tblsalesdetails`
  ADD CONSTRAINT `tblsalesdetails_ibfk_2` FOREIGN KEY (`Pro_ID`) REFERENCES `tblproducts` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblsalesdetails_ibfk_3` FOREIGN KEY (`Sale_ID`) REFERENCES `tblsales` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
